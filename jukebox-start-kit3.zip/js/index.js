class JukeBox{
 
  
 playPause(){
   var track = document.getElementById('track');
   var button = document.getElementById("button");
   var button2 = document.getElementById("button2");
  
	
   if (track.paused) {
	    track.play();
	    button.className = "pause";
	
  } else {	
      track.pause();
	    button.className = "play";
      button2.className = "stop";
  }
}
}

var jx = new JukeBox()
document.getElementById("button").addEventListener("click", jx.playPause);
document.getElementById("button2").addEventListener("click", jx.playPause);


//jx.play(btn)